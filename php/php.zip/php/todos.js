$(document).ready(function(){
        $("#clear-button").click(function(){
            $("a[target='_blank']").hide();
            $("form")[0].reset();
  });
  });
