<meta http-equiv="content-type" content="text/html" charset="utf-8">
<?php
$conexao  = @mysql_connect("localhost","root","") or die ("Erro");
?>



<?php echo $nome_pessoas
       echo $id_pessoas
             $sql_pessoas = mysql_query("select * from pessoas");
              $total_nome = mysql_num_rows($sql_listar_pessoas);
   while ($resultado_pessoas = $resultado_nome['id']);?>
