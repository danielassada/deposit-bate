
<?php
if(isset($_POST['add']))
{
$dbhost = 'localhost:3306';
$dbuser = 'root';
$dbpass = 'roses25violet';
$dbname = "Deposit";
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}

if(! get_magic_quotes_gpc() )
{
   $titulo = addslashes ($_POST['titulo']);
   $body = addslashes ($_POST['body']);
   $ano = addslashes ($_POST['ano']);
   $obs = addslashes ($_POST['obs']);
   $autor = addslashes ($_POST['autor']);
}
else
{
  $titulo = ($_POST['titulo']);
  $body = ($_POST['body']);
  $ano = ($_POST['ano']);
  $obs = ($_POST['obs']);
  $autor = ($_POST['autor']);
}
$sql = "INSERT INTO artigos ".
       "(title,author,body,born,note) ".
       "VALUES ".
       "('$titulo','$autor','$body','$ano','$obs')";
$retval = mysqli_query( $conn,$sql );
if(! $retval )
{
  die('Could not enter data: ');
}
echo "Entered data successfully\n";
mysqli_close($conn);
}
else
{
?>
<form method="post" action="<?php $_PHP_SELF ?>">
<table width="600" border="0" cellspacing="1" cellpadding="2">
<tr>
<td width="250">Título</td>
<td>
<input name="titulo" type="text" id="titulo">
</td>
</tr>
<tr>
<td width="250">artigo</td>
<td>
<textarea name="body" class="form-control" rows="10" cols="91" id="body"></textarea>
</td>
</tr>
<tr>
<td width="250">ano</td>
<td>
<input name="ano" type="text" id="ano">
</td>
</tr>
<tr>
<td width="250">observação</td>
<td>
<input name="obs" type="text" id="obs">
</td>
</tr>
<tr>
<td width="250">autor</td>
<td>
<input name="autor" type="text" id="autor">
</td>
</tr>
<tr>
<td width="250"></td>
<td>
<input name="add" type="submit" id="add" value="Add">
</td>
</tr>
</table>
</form>
<?php
}
?>
