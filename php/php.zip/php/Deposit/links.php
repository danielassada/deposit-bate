<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="estilo.css" type="text/css">
    <script>
function pesquisa(){
  window.open("pesquisasLink.php", "_self", "");
}
function link(){
  window.open("index.php", "_self", "");
}
    </script>
  </head>
  <body>

    <div id="nav">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav">
        <li class="active"><a href="https://10.0.0.10">home <span class="sr-only">(abyss)</span></a></li>
        <li><a href="index.html">home</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Desenvolvedor <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="https://www.similarweb.com/">similares</a></li>
            <li><a href="https://www.woorank.com/pt">analise de webpag</a></li>
            <li><a href="http://www.seoworkers.com/sitemap.html">mapa de pagina</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="http://www.w3schools.com/">intruções de web desen</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="http://getbootstrap.com/">bootstrap</a></li>
          </ul>
        </li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li><a href="pg1.html">blog</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">musicas <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="youtube.html">youtube</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="playlist/phard.html">play list hard</a></li>

          </ul>
        </li>

      </ul>

    </div><!-- /.navbar-collapse -->

  </div><!-- /.container-fluid -->






 <div id="dois" onclick="pesquisa()" class="btn"
  ><h2>Pesquisa classes
</h2>
 </div>
 <div id="tres" onclick="link()" class="btn"
  ><h2> Artigos
</h2>
 </div></a>





<table align="left" border="0" cellpadding="0" cellspacing="0" topmargin="0" >
<tr valign="top" id="columns">

<td width="385">
<table class="column" cellspacing="0" cellpadding="0">
<!-- TODO:  DAF Connect? -->


<tr class="item">
  <td class="itemcontent">

    <form method="post" action="postLink.php">
    <table width="600" border="0" cellspacing="1" cellpadding="2">
    <tr>
    <td width="250">titulo</td>
    <td>
    <input name="titulo" type="text" id="titulo">
    </td>
    </tr>
    <tr>
    <td width="250">Tipo</td>
    <td>
    <textarea name="tipo" class="form-control" rows="2" cols="91" id="tipo"></textarea>
    </td>
    </tr>
    <tr>
    <td width="250">descricao</td>
    <td>
    <textarea name="descricao" class="form-control" rows="10" cols="91" type="text" id="descricao">
      </textarea>
    </td>
    </tr>
    <tr>
    <td width="550">observacao</td>
    <td>
    <input name="observacao" type="text" id="observacao">
    </td>
    </tr>
    <tr>
    <td width="550">Link</td>
    <td>
    <input name="link" type="text" id="link">
    </td>
    </tr>
    <tr>
    <td width="250"></td>
    <td>
    <input name="add" type="submit" id="add" value="Add">
    </td>
    </tr>
    </table>
    </form>
  </td>
</tr>

</table>




<!-- <div id="content">
<table align="left" border="0" cellpadding="0" cellspacing="0" topmargin="0" >
<tr valign="top" id="columns">
   <a href="busca.0.1.php">busca0.1</a>
   <a href="phpinfo.php">info</a>
   <a href="busca.php">busca</a>
</tr>
</table>
</div> -->
  </body>
</html>
